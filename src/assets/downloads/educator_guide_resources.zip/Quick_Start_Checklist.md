# Quick‑Start Checklist

1. **Create your Educator account** (Google / Microsoft SSO).
2. **Download a Curriculum Kit** that fits your grade band.
3. **Review the Ethics Guide** – focus on the radar chart.
4. **Assign a starter scenario** to a test class.
5. **Open the Learning Analytics Dashboard** once students finish.
6. **Use the Ethical Reasoning Rubric** for formative feedback.