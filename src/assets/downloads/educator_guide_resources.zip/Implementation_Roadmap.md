# Implementation Roadmap

| Phase | Time Frame | Key Actions |
|-------|------------|-------------|
| **Explore** | Week 1 | Class demo of one scenario; think‑pair‑share debrief. |
| **Apply**   | Weeks 2‑3 | Students run scenarios in pairs; submit radar reflections. |
| **Create**  | Week 4+ | Teams design their own ethical dilemmas; peer review. |