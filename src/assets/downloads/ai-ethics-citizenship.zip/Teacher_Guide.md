# Digital Citizenship & AI Ethics – Teacher Guide (Grades 9‑12)

**Duration:** 3 × 50‑minute lessons  
**Focus Dimensions:** Fairness, Accountability, Privacy, Transparency  
**ISTE Standards:** 1.2 Digital Citizen, 3.3 Knowledge Constructor, 4.4 Innovative Designer

## Learning Objectives
1. Identify ethical trade‑offs in real‑world AI applications.  
2. Debate the impact of privacy decisions on transparency and fairness.  
3. Produce a civic call‑to‑action grounded in ethical reasoning.

## Lesson Flow
| Day | Activity | Key Moves | Materials |
|-----|----------|-----------|-----------|
| 1 | *Hook:* Facial‑recognition video. Mini‑lecture on SimulateAI radar chart. | Whole‑class discussion | Slide deck 1, student devices |
| 2 | *Scenario:* Students run SimulateAI “Smart City Cameras” case in pairs. | Radar reflection; jigsaw share‑out | Student worksheet, laptops |
| 3 | *Action Plan:* Groups design a school policy poster. | Gallery walk with rubric feedback | Poster paper or Canva |

## Assessment
- **Formative:** Radar chart screenshots + reflection (Worksheet Q4‑Q6)  
- **Summative:** Policy poster scored with Ethical Reasoning Rubric (see Assessment Tools)

## Differentiation
- Provide sentence starters for EL students.  
- Offer “challenge cards” for early finishers to extend dimension analysis.