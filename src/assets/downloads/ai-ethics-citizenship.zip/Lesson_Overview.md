# Lesson Overview

| Component | Purpose | Time |
|-----------|---------|------|
| Hook Video & Discussion | Engage interest, activate prior knowledge | 10 min |
| Mini Lecture | Introduce ethical dimensions & radar chart | 15 min |
| Scenario Exploration | Apply concepts in simulation | 25 min |
| Reflection & Debrief | Consolidate learning | 15 min |
| Action Plan Poster | Authentic application | 35 min |