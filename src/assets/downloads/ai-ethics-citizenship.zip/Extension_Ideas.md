# Extension Ideas

* **ELA Tie‑In:** Write an op‑ed for the school newspaper arguing for or against facial recognition on campus.  
* **Social Studies:** Compare global regulations (e.g., GDPR vs. U.S. frameworks).  
* **Tech Option:** Prototype an ethical notice banner using HTML/CSS that informs users how their data is used.