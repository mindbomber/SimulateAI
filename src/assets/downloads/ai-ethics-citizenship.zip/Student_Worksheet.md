# Digital Citizenship & AI Ethics – Student Worksheet

**Name:** __________________   **Period:** _______

### Part 1 — Pre‑Scenario Reflection
1. What do you already know about AI in public spaces?

### Part 2 — Simulation Notes
Record your radar chart scores after each major decision point:

| Decision Point | Fairness | Sustainability | Autonomy | Beneficence | Transparency | Accountability | Privacy | Proportionality |
|----------------|----------|----------------|----------|-------------|--------------|---------------|---------|-----------------|
| 1 | | | | | | | | |
| 2 | | | | | | | | |
| 3 | | | | | | | | |

### Part 3 — Critical Analysis
1. Which two dimensions were most difficult to balance? Why?  
2. Describe one unintended consequence that emerged in your scenario.

### Part 4 — Action Plan
Draft a policy statement (100–150 words) your school could adopt to ensure ethical use of surveillance technologies.