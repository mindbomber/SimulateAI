# Peer Review Protocol

1. **Present (3 min):** Team A summarizes their solution & shows radar shape.  
2. **Clarify (2 min):** Audience asks clarifying questions only.  
3. **Warm Feedback (2 min):** Audience notes strengths tied to specific dimensions.  
4. **Cool Feedback (2 min):** Audience suggests improvements; reference rubric.  
5. **Reflection (2 min):** Team A records next‑step actions.