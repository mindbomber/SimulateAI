# Ethical Reasoning Rubric

| Level | Description |
|-------|-------------|
| **4 – Exemplary** | Thoroughly explains trade‑offs; integrates multiple dimensions; proposes innovative, context‑appropriate solutions. |
| **3 – Proficient** | Identifies key conflicts; addresses most dimensions; suggests reasonable solutions. |
| **2 – Developing** | Mentions some dimensions but limited analysis; solutions lack depth. |
| **1 – Beginning** | Surface‑level or incorrect ethical references; solutions missing or impractical. |