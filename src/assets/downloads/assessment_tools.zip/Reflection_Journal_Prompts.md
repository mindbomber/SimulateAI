# Reflection Journal Prompts

1. Which ethical dimension felt most intuitive to you today? Least intuitive?  
2. Describe a time you prioritized one dimension over another in the simulation.  
3. How might the outcome change if you reversed that priority?  
4. Connect today’s scenario to a real‑world example from news or personal life.  
5. If you could ask an expert one question about this dilemma, what would it be?