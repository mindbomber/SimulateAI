# Data Literacy & Bias Detection – Student Sheet

1. Review the *Hiring Algorithm* scenario and record initial radar scores.  
2. Analyze the provided data‑set excerpt. Highlight any anomalies.

| Field | Observation | Possible Bias? |
|-------|-------------|----------------|
| College Tier | | |
| Years Experience | | |
| Skill Score | | |

3. Re‑run the scenario after cleaning the data. How did scores change?