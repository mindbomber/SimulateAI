# Data Literacy & Bias Detection – Teacher Guide (Grades 7‑10)

**Duration:** 2 × 60‑minute lessons  
**Focus Dimensions:** Fairness, Beneficence, Accountability

## Objectives
1. Detect bias in sample data sets.  
2. Correlate bias to radar chart dimension shifts.  
3. Craft recommendations to mitigate bias.

## Materials
- SimulateAI “Hiring Algorithm” scenario  
- Printed data‑set excerpts  
- Spreadsheet software  
- Reflection Journal