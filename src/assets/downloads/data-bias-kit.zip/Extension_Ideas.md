# Extension & Enrichment

- **Math Connection:** Calculate statistical measures of central tendency before and after cleaning.  
- **Art Connection:** Design an infographic summarizing bias impact on hiring diversity.