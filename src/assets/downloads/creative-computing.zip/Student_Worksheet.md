# Creative Computing – Project Planner

1. Ethical dilemma your animation will address: ____________________  
2. Choose two dimensions to highlight and explain why.

3. Storyboard (sketch boxes below):
| Scene | Action | Dimension Focus |
|-------|--------|-----------------|
| 1 | | |
| 2 | | |
| 3 | | |

4. Reflection: After seeing classmates’ projects, what surprised you about the trade‑offs?