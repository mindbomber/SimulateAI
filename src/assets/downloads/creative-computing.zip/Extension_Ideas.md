# Further Challenges

- **Micro:bit Sensor Add‑On:** Collect live temperature data and show it in the animation.  
- **Community Outreach:** Present final projects during school sustainability fair.