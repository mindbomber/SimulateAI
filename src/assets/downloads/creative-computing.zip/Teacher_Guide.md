# Creative Computing with Ethics – Teacher Guide (Grades 5‑8)

**Duration:** 3 × 45‑minute lessons  
**Focus Dimensions:** Beneficence, Sustainability, Proportionality

## Overview
Students create a block‑code animation that teaches younger peers about an environmental ethics dilemma.

## Day‑By‑Day
| Day | Task |
|-----|------|
| 1 | Introduce radar chart & brainstorm environmental issues |
| 2 | Code animation in Scratch or MakeCode |
| 3 | Peer showcase & dimension reflection |